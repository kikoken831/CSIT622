Both local and cappa environment:
First to compile the codes 
javac FileSystem.java

And run the code:
java FileSystem //to enter login page
java FileSystem -i //to enter create account page